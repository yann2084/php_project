CREATE TABLE annonce (
	id_annonce INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
	titre TEXT,
	description TEXT,
	id_region INTEGER NOT NULL,
	id_cat INTEGER NOT NULL,
	kilomètre INTEGER,
	heure INTEGER,
	prix REAL,
	id_user INTEGER NOT NULL,
	image TEXT,
	id_marque INTEGER NOT NULL,
	date_mel DATE, --AAAA/MM/JJ
	annee INTEGER,
	FOREIGN KEY(categorie) REFERENCES categorie(id_cat),
	FOREIGN KEY(user) REFERENCES user(id_user),
	FOREIGN KEY(marque) REFERENCES marque(id_marque),
	FOREIGN KEY(region) REFERENCES region(id_region)
);

/*CREATE TABLE ti_user_annonce (
	id_user INTEGER PRIMARY KEY,
	id_annonce INTEGER PRIMARY KEY,
	FOREIGN KEY(annonce) REFERENCES annonce(id_annonce),
	FOREIGN KEY(user) REFERENCES user(id_user)
);*/

CREATE TABLE user (
	id_user INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
	pseudo TEXT,
	nom TEXT,
	prenom TEXT,
	mdp TEXT,
	codePostal INTEGER,
	ville TEXT,
	mail TEXT,
	photo TEXT
);

CREATE TABLE categorie (
	id_cat INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
	lib_cat TEXT
);

CREATE TABLE region (
	id_region INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
	lib_region TEXT
);

CREATE TABLE marque (
	id_marque INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
	lib_marque TEXT
);
